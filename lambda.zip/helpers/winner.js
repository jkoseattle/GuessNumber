'use strict';

var Alexa = require('alexa-sdk');

var winner = (function () {
    this.emit(':tell', 'you guessed. Hope you\'re proud of yourself. Ok bye.');
  });
  module.exports = winner;
  