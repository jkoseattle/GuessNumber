'use strict';

var Alexa = require('alexa-sdk');
var constants = require('../constants/constants');
var winner = require('../helpers/winner');
var randomPhrase = require('../helpers/randomPhrase');

var playing1StateHandlers = Alexa.CreateStateHandler(constants.states.PLAYING1, {

    'GuessNumber': function () { 
        // Get Welcome phrase
        // var answerPhrase = new randomPhrase(playing1Phrases, ); 

        // this.handler.state = welcomePhrase.NextState;
        // this.emit(':tell', `my number is ${chosenNumber}. ${welcomePhrase.Phrase} `);
    },
    'AMAZON.StopIntent': function () {
        this.emit(':tell', `Playing. Stop intent`);
    },
    
    'AMAZON.CancelIntent': function () {
        this.emit(':tell', 'Cancel intent');
    },
    
    'SessionEndedRequest': function () {
        this.emit(':tell', 'Session ended');
    },
    
    'AMAZON.HelpIntent': function () {
        this.emit(':ask', 'Help intent');
    },
    
    'Unhandled': function () {
        this.emitWithState('AMAZON.HelpIntent');
    }
    
});

module.exports = playing1StateHandlers;
