'use strict';

var constants = require('../constants/constants');

var playing0Phrases = [
  {
    'Phrase': 'My number is <comp> than <guess>. Guess again.',
    // 'NextState': constants.states.PLAYING1
  },
  {
    'Phrase': '<guess> is <oppComp> than my number. Next guess.',
    // 'NextState': constants.states.PLAYING1
  },
  {
    'Phrase': 'It\'s <comp> than <guess>. Try again.',
    // 'NextState': constants.states.PLAYING1
  },
];

// DEBUG PHRASE
// var playing0Phrases = [
//   {   
//     'Phrase': `Please stand by. Due to higher than normal call volumes, your guess will be evaluated in. <prosody pitch="-33%"><minutes></prosody> Minutes. <hold> Just kidding. The answer is <comp>.`,
//     // 'NextState': constants.states.PLAYING1
//   }
// ];

module.exports = playing0Phrases;
